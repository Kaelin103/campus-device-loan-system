// src/index.js
require("./functions/health");
require("./functions/getAdminLoans");
require("./functions/getLoans");
require("./functions/collectLoan");
require("./functions/reserveLoan");
require("./functions/returnLoan");
