// index.js (root)
require("./src/index");
