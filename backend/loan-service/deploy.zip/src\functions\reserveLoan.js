// src/functions/reserveLoan.js
const { app } = require("@azure/functions");
const { ensureSetup, getLoansContainer } = require("../cosmosClient");
const auth0JwtCheck = require("../auth/auth0Jwt");
const runMiddleware = require("../auth/azureAdapter");

app.http("reserveLoan", {
  methods: ["POST"],
  authLevel: "anonymous",
  route: "loans/reserve",
  handler: async (request, context) => {
    context.log("Reserving loan");

    const jwtResult = await runMiddleware(request, auth0JwtCheck);
    if (jwtResult.isResponse) return jwtResult.response;

    const userId = jwtResult.req.auth?.payload?.sub;
    const body = await request.json();

    if (!body?.deviceId) {
      return { status: 400, jsonBody: { message: "deviceId required" } };
    }

    await ensureSetup();
    try {
      const container = getLoansContainer();
      const loan = {
        id: crypto.randomUUID(),
        userId,
        deviceId: body.deviceId,
        status: "reserved",
        createdAt: new Date().toISOString(),
      };

      await container.items.create(loan);
      return { status: 201, jsonBody: loan };
    } catch (err) {
      context.log("Reserve failed", err);
      return { status: 500, jsonBody: { message: "Internal Server Error" } };
    }
  },
});
