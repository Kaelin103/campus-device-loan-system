// src/functions/collectLoan.js
const { app } = require("@azure/functions");
const { ensureSetup, getLoansContainer } = require("../cosmosClient");
const auth0JwtCheck = require("../auth/auth0Jwt");
const requireStaff = require("../auth/requireStaff");
const runMiddleware = require("../auth/azureAdapter");

app.http("collectLoan", {
  methods: ["POST"],
  authLevel: "anonymous",
  route: "loans/{id}/collect",
  handler: async (request, context) => {
    const jwt = await runMiddleware(request, auth0JwtCheck);
    if (jwt.isResponse) return jwt.response;

    const staff = await runMiddleware(jwt.req, requireStaff);
    if (staff.isResponse) return staff.response;

    const loanId = request.params.id;

    await ensureSetup();
    try {
      const container = getLoansContainer();
      const { resource } = await container.item(loanId, loanId).read();

      resource.status = "collected";
      resource.collectedAt = new Date().toISOString();

      await container.items.upsert(resource);
      return { status: 200, jsonBody: resource };
    } catch (err) {
      context.log("Collect failed", err);
      return { status: 500, jsonBody: { message: "Internal Server Error" } };
    }
  },
});
