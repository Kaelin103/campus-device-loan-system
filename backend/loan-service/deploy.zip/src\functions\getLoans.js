// src/functions/getLoans.js
const { app } = require("@azure/functions");
const { ensureSetup, getLoansContainer } = require("../cosmosClient");
const auth0JwtCheck = require("../auth/auth0Jwt");
const runMiddleware = require("../auth/azureAdapter");

app.http("getLoans", {
  methods: ["GET"],
  authLevel: "anonymous",
  route: "loans/me",
  handler: async (request, context) => {
    context.log("Fetching user loans");

    // 1. Auth
    const jwtResult = await runMiddleware(request, auth0JwtCheck);
    if (jwtResult.isResponse) return jwtResult.response;

    const userId = jwtResult.req.auth?.payload?.sub;
    if (!userId) {
      return { status: 401, jsonBody: { message: "Unauthorised" } };
    }

    // 2. Business logic
    await ensureSetup();
    try {
      const container = getLoansContainer();
      const query = {
        query: "SELECT * FROM c WHERE c.userId = @uid ORDER BY c.createdAt DESC",
        parameters: [{ name: "@uid", value: userId }],
      };

      const { resources } = await container.items.query(query).fetchAll();
      return { status: 200, jsonBody: resources };
    } catch (err) {
      context.log("Error fetching user loans", err);
      return { status: 500, jsonBody: { message: "Internal Server Error" } };
    }
  },
});
